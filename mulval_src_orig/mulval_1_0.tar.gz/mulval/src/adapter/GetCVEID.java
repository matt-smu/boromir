/*
Get CVE IDs from each OVAL report.
Author(s) : Su Zhang, Xinming Ou
Copyright (C) 2011, Argus Cybersecurity Lab, Kansas State University

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.File;
import java.io.FileWriter;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

//import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;
import java.util.Hashtable;

public class GetCVEID {

	
	public static void main(String[] args) {
		String name = args[0];
		clear(name);
		getCVEs(name);
		//getHostname(name);
        // makehashTable(name);
		//Hashtable hs= new Hashtable();
		//Hashtable hs= makehashTable(name);
	//	hs.put( hashfunction("\"oval:org.mitre.oval:def:69\""), "\"oval:org.mitre.oval:def:69\"");
		//System.out.println(hashfunction("\"oval:org.mitre.oval:def:69\""));
		//hs.put( hashfunction("\"oval:org.mitre.oval:def:68\""), "\"oval:org.mitre.oval:def:68\"");

		//System.out.println(hs.size());
	//	System.out.println(hs.contains("\"oval:org.mitre.oval:def:67\""));

	}
	public static String getHostname(String filename){
		 String hname="";
try{
			
			SAXReader saxReader = new SAXReader(); 
		    Document document = saxReader.read(filename);
		    Element   hostname   =(Element)   document.selectSingleNode( "/*[local-name(.)='oval_results']/*[local-name(.)='results']/*[local-name(.)='system']/*[local-name(.)='oval_system_characteristics']/*[local-name(.)='system_info']/*[local-name(.)='primary_host_name']"   ); 
		 String hname1=hostname.getText();
                 System.out.println(hname1);
                 
                 
		int in=hname1.indexOf('.');  //only keep the string before the first dot
		
	//	System.out.println("index is:"+in);
		
		//if no dot, then ignore it
		if(in==-1)
			in=0;
		
		 hname=hname1.substring(0,in);
		    System.out.println("host name is: "+hname);
}

catch (Exception e){
	 
	 e.printStackTrace();
}

	return hname;	
		
	}
	
	@SuppressWarnings("unchecked")
	public static void clear(String filename){
		
		
try{
			
			SAXReader saxReader = new SAXReader(); 
		    Document document = saxReader.read(filename);
		    Element   definitions   =(Element)   document.selectSingleNode( "/*[local-name(.)='oval_results']/*[local-name(.)='oval_definitions']/*[local-name(.)='definitions']"   ); 

			List clas=document.selectNodes("/*[local-name(.)='oval_results']/*[local-name(.)='oval_definitions']/*[local-name(.)='definitions']/*[local-name(.)='definition']/@class" ); 
			Iterator cls = clas.iterator();

			while(cls.hasNext()){
	        	//System.out.println("1");

				Attribute clss = (Attribute)cls.next();

				 if(clss.getText().contains( "inventory"))
			        { 
					 
					
			        	//System.out.println(definitions.getName());
			          definitions.remove(clss.getParent()); 
			          XMLWriter   output   =   new   XMLWriter(new   FileWriter( filename));//
			          output.write(   document   ); 
			          output.flush(); 
			          output.close(); 
			          
			        } 

			
			}
			
			
		}
		 catch (Exception e){
			 
			 e.printStackTrace();
		 }
		
		
		
	}
	
	@SuppressWarnings("unchecked")
	public static void getCVEs(String filename){
		Hashtable cve= makehashTable(filename);
		String hname=getHostname(filename);
		try{
			
			FileWriter fr= new FileWriter("CVE.txt");
			SAXReader saxReader = new SAXReader(); 
			Document document = saxReader.read(new File(filename));
			List<String> lid = document.selectNodes("/*[local-name(.)='oval_results']/*[local-name(.)='oval_definitions']/*[local-name(.)='definitions']/*[local-name(.)='definition']/@id" ); 
			Iterator itid = lid.iterator();
			List<String> lrid=document.selectNodes("/*[local-name(.)='oval_results']/*[local-name(.)='oval_definitions']/*[local-name(.)='definitions']/*[local-name(.)='definition']/*[local-name(.)='metadata']/*[local-name(.)='reference']/@ref_id" ); 
			Iterator itrid = lrid.iterator();
			//String hname=getHostname(filename);
			fr.write(hname+"\n");
			
			while(itid.hasNext()){
    
				Attribute id = (Attribute)itid.next();
				Attribute rid = (Attribute)itrid.next();
			
					if(cve.contains(id.getText())){
					  //  System.out.println(id.getText());
						fr.write(rid.getText()+"\n");
						
					}
			
			}
			//System.out.println(cve.contains("oval:org.mitre.oval:def:227"));
			//System.out.println(i);
			fr.close();
			
		}
		 catch (Exception e){
			 
			 e.printStackTrace();
		 }
		
	}
	@SuppressWarnings("unchecked")
	public static Hashtable<Integer, String>  makehashTable(String filename){
		Hashtable<Integer, String> hs= new Hashtable<Integer, String>();
		
try{
			SAXReader saxReader = new SAXReader(); 
		    Document document = saxReader.read(new File(filename));
		
		List <String>ldid = document.selectNodes("/*[local-name(.)='oval_results']/*[local-name(.)='results']/*[local-name(.)='system']/*[local-name(.)='definitions']/*[local-name(.)='definition']/@definition_id" ); 
		Iterator itdid = ldid.iterator();
		List <String>rst = document.selectNodes("/*[local-name(.)='oval_results']/*[local-name(.)='results']/*[local-name(.)='system']/*[local-name(.)='definitions']/*[local-name(.)='definition']/@result" ); 
		Iterator result = rst.iterator();

		while(itdid.hasNext()){
			Attribute defid = (Attribute)itdid.next();
			Attribute rs = (Attribute)result.next();
		
			if (rs.getText().contains("true")){
				
			hs.put(hashfunction(defid.getText()), defid.getText());
		//	System.out.println(defid.getText());
		//	System.out.println(hashfunction(defid.getText()));

				//fr.write(rid.getText()+"\n");
				
				
			}
			
			

			}
		//System.out.println(hs.contains(""));

		//hs.put("1", "1");
		//hs.put("2", "2");
		System.out.println(hs.size());
		//return hs;
		
}
		catch (Exception e){
			 
			 e.printStackTrace();
		 }
return hs;
		
		
		
	}
	public static int hashfunction(String key){
		int l=key.length();
	String k=	key.substring(24,l);
	int result= Integer.parseInt(k);
	return result;
		
		
	}

}